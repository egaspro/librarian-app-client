import React, { Component } from 'react';

export default function NotRecognized() {
	return (
		<div>
			<h1> You cannot be here! Get the Hell out!! </h1>
		</div>
	);
};