import React from 'react';

export default function NotFound() {
	return (
		<div>
			<h1> There's no such thing in Library! </h1>
		</div>
	);
};